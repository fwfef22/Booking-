using Application.DTOs;
using Infrastructure.Repositories;
using Domain;
using Microsoft.EntityFrameworkCore;

namespace Application.Services;

public class PaymentService : IPaymentService
{
    private readonly IPaymentRepository _repository;
    private readonly IReservationRepository _reservationRepository;

    public PaymentService(IPaymentRepository repository, IReservationRepository reservationRepository)
    {
        _repository = repository;
        _reservationRepository = reservationRepository;
    }

    public async Task<GeneralResponse> CreatePaymentAsync(CreatePaymentDto request)
    {
        var reservation = await _reservationRepository.GetByIdAsync(request.Reservation_ID);
        if (reservation == null)
        {
            return new GeneralResponse
            {
                Success = false,
                Message = "Reservation not found."
            };
        }

        if(request.Amount <= 0)
        {
            return new GeneralResponse
            {
                Success = false,
                Message = "Amount must be greater than zero."
            };
        }

        var payment = new Payment
        {
            Amount = request.Amount,
            Reservation_ID = request.Reservation_ID,
            Status = "Pending",
            CreatedAt = DateTime.UtcNow
        };

        payment.Status = "Completed";
        payment.CompletedAt = DateTime.UtcNow;

        reservation.Status = "Paid";

        await _repository.AddAsync(payment);
        await _repository.SaveChangesAsync();

        return new GeneralResponse
        {
            Success = true,
            Message = "Payment created and reservation updated successfully."
        };
    }

    public async Task<PaymentDto> GetPaymentByPaymentId(string paymentId)
    {
        var payment = await _repository.Query().FirstOrDefaultAsync(p => p.Payment_ID == paymentId);
        if (payment == null) return null;

        return new PaymentDto
        {
            Payment_ID = payment.Payment_ID,
            Amount = payment.Amount,
            Status = payment.Status,
            CreatedAt = payment.CreatedAt,
            CompletedAt = payment.CompletedAt,
            Reservation_ID = payment.Reservation_ID
        };
    }

    public async Task<List<PaymentDto>> GetPaymentsByReservationId(string reservationId)
    {
        var payments = await _repository.Query()
            .Where(p => p.Reservation_ID == reservationId)
            .ToListAsync();

        return payments.Select(payment => new PaymentDto
        {
            Payment_ID = payment.Payment_ID,
            Amount = payment.Amount,
            Status = payment.Status,
            CreatedAt = payment.CreatedAt,
            CompletedAt = payment.CompletedAt,
            Reservation_ID = payment.Reservation_ID
        }).ToList();
    }
    public async Task<List<PaymentDto>> QueryPaymentsAsync(PaymentQueryDto query)
    {
        var q = _repository.Query();

        if (!string.IsNullOrWhiteSpace(query.PaymentId))
        {
            q = q.Where(p => p.Payment_ID == query.PaymentId);
        }

        if (!string.IsNullOrWhiteSpace(query.ReservationId))
        {
            q = q.Where(p => p.Reservation_ID == query.ReservationId);
        }

        if (query.Amount.HasValue)
        {
            q = q.Where(p => p.Amount == (decimal)query.Amount.Value);
        }

        if (!string.IsNullOrWhiteSpace(query.Status))
        {
            q = q.Where(p => p.Status == query.Status);
        }

        if (query.CreatedAt.HasValue)
        {
            var start = query.CreatedAt.Value.Date;
            var end = start.AddDays(1);
            q = q.Where(p => p.CreatedAt >= start && p.CreatedAt < end);
        }

        if (query.CompletedAt.HasValue)
        {
            var start = query.CompletedAt.Value.Date;
            var end = start.AddDays(1);
            q = q.Where(p => p.CompletedAt.HasValue && p.CompletedAt.Value >= start && p.CompletedAt.Value < end);
        }

        var payments = await q.ToListAsync();

        return payments.Select(payment => new PaymentDto
        {
            Payment_ID = payment.Payment_ID,
            Amount = payment.Amount,
            Status = payment.Status,
            CreatedAt = payment.CreatedAt,
            CompletedAt = payment.CompletedAt,
            Reservation_ID = payment.Reservation_ID
        }).ToList();
    }
}