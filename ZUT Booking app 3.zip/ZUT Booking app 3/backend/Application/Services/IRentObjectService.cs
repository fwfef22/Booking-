using Application.DTOs;

namespace Application.Services;

public interface IRentObjectService
{
    Task<GeneralResponse> CreateAsync(CreateRentObjectRequest request);
    Task<List<RentObjectDto>> SearchObjectsAsync(Application.DTOs.Object.SearchRentObjectRequest request);
    Task<RentObjectDto> GetRentObjByIdAsync(string RentObjID);
    Task<RentObjectRoomDto> GetRentObjRoomByIdAsync(string RentObjRoomID);
    Task<List<RentObjectDto>> GetRentObjLimit(int Limit);
}