namespace Application.DTOs;
public class ReservationDto
{
    public string RentObjectRoomId { get; set; } = string.Empty;
    public string Reservation_ID { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;

    public string Status { get; set; } = "Pending";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime ReservationDate { get; set; }

    public TimeSpan ReservationTime { get; set; }
}