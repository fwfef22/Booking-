namespace Application.DTOs;

public class PaymentDto
{
    public string Payment_ID { get; set; } = string.Empty;
    public string Reservation_ID { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
}