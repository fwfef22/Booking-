namespace Application.DTOs;

public class PaymentQueryDto
{
    public string? PaymentId { get; set; } 
    public string? ReservationId { get; set; } 
    public decimal? Amount { get; set; }
    public string? Status { get; set; } 
    public DateTime? CreatedAt { get; set;  }
    public DateTime? CompletedAt { get; set; } 
}