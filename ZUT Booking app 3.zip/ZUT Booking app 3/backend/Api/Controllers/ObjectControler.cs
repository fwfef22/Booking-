using Microsoft.AspNetCore.Mvc;
using Application.Services;
using Application.DTOs;
using Application.DTOs.Object;

namespace Api.Controllers;

[ApiController]
[Route("api/Rent_Object")]

public class ObjectController : ControllerBase
{
    private readonly IRentObjectService _service;

    public ObjectController(IRentObjectService service) => _service = service;

    [HttpPost("search")]
    public async Task<ActionResult<List<RentObjectDto>>> SearchObjectsAsync([FromBody] SearchRentObjectRequest request)
    {
        var objects = await _service.SearchObjectsAsync(request);
        return Ok(objects);
    }

    [HttpPost("create-rent_object")]
    public async Task<ActionResult<GeneralResponse>> CreateObject([FromBody] CreateRentObjectRequest request)
    {
        var response = await _service.CreateAsync(request);
        return Ok(response);
    }

    [HttpGet("RentObjectByID")]
    public async Task<ActionResult<RentObjectDto>> GetRentObjByID(string RentObjID)
    {
        var RentObj = await _service.GetRentObjByIdAsync(RentObjID);
        if (RentObj == null)
            return NotFound(new { message = "Rent Object not found" });
        return Ok(RentObj);
    }

    [HttpGet("RentObjectWithLimit")]
    public async Task<ActionResult<RentObjectDto>> GetRentObjByLimit(int Limit)
    {
        var RentObj = await _service.GetRentObjLimit(Limit);
        return Ok(RentObj);
    }

    [HttpGet("RentObjectRoomByID")]
    public async Task<ActionResult<RentObjectRoomDto>> GetRentObjRoomByID(string RentObjRoomID)
    {
        var RentObjRoom = await _service.GetRentObjRoomByIdAsync(RentObjRoomID);
        if (RentObjRoom == null)
            return NotFound(new { message = "Rent Object Room not found" });
        return Ok(RentObjRoom);
    }
}