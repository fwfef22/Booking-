﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain;
namespace Infrastructure.Persistence.EntityTypeConfigurations;
public class RentObjectConfiguration : IEntityTypeConfiguration<Domain.Rent_Object>
{
    public void Configure(EntityTypeBuilder<Domain.Rent_Object> builder)
    {
        builder.HasKey(o => o.Rent_Object_ID);
        builder.Property(o => o.Name).IsRequired();
        builder.HasOne(o => o.Owner)
            .WithMany(u => u.Objects)
            .HasForeignKey(o => o.Owner_ID)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);
        
    }
}
