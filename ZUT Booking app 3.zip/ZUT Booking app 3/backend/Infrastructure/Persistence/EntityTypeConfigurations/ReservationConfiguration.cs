﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Domain;
namespace Infrastructure.Persistence.EntityTypeConfigurations;
public class ReservationConfiguration : IEntityTypeConfiguration<Domain.Reservation>
{
    public void Configure(EntityTypeBuilder<Domain.Reservation> builder)
    {
        builder.HasKey(r => r.Reservation_ID);
        builder.Property(r => r.ReservationDate).IsRequired();
        builder.Property(r => r.Status).IsRequired().HasDefaultValue("Pending");
        builder.HasOne(r => r._user)
            .WithMany(u => u.Reservations)
            .HasForeignKey(r => r.User_ID)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
        builder.HasOne(r => r.Room)
            .WithMany(rm => rm.Reservations)
            .HasForeignKey(r => r.Room_ID)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

    }
}
