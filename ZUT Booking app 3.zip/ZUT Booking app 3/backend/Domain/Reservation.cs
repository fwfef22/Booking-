﻿namespace Domain;

public class Reservation
{
    public string Reservation_ID { get; set; } = Guid.NewGuid().ToString("N");
   
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime ReservationDate { get; set; } = DateTime.UtcNow;

    public TimeSpan ReservationTime { get; set; } = TimeSpan.Zero;

    public string Status { get; set; } = "Pending";

    public string Room_ID { get; set; } = string.Empty;
    public Rent_Object_Room Room { get; set; } = new(); 

    public string User_ID { get; set; } = string.Empty;
    public User _user { get; set; } = new User();

    public ICollection<Payment> Payments { get; set; } = new List<Payment>();



}

