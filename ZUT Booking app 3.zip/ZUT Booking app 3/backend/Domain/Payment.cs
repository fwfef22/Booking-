namespace Domain;

public class Payment
{
    public string Payment_ID { get; set; } = Guid.NewGuid().ToString("N");
    public decimal Amount { get; set; }

    public string Status { get; set; } = "Pending";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime? CompletedAt { get; set; }

    public string Reservation_ID { get; set; } = string.Empty;
    public Reservation? Reservation { get; set; }
}