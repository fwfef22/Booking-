import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { getUserReservations, getRoomDetailsById } from "../services/api";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Calendar, Clock, MapPin, Loader2 } from "lucide-react";
import { toast } from "sonner";

export function MyReservations() {
    const { user, token } = useAuth();
    const [reservations, setReservations] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchMyData = async () => {
            if (!user?.user_ID || !token) return;

            try {
                const rawReservations = await getUserReservations(user.user_ID, token);

                const detailedReservations = await Promise.all(
                    rawReservations.map(async (res: any) => {
                        try {
                            const details = await getRoomDetailsById(res.rentObjectRoomId, token);
                            return {
                                ...res,
                                roomName: details.name_Object_Room,
                                objectName: details.name_Object,
                                address: `${details.adres_Miasto}, ${details.adres_Ulica_1}`
                            };
                        } catch (err) {
                            return { ...res, roomName: "Sala", objectName: "Obiekt" };
                        }
                    })
                );

                setReservations(detailedReservations);
            } catch (error) {
                console.error(error);
                toast.error("Nie udało się pobrać Twoich rezerwacji");
            } finally {
                setIsLoading(false);
            }
        };

        fetchMyData();
    }, [user, token]);

    if (isLoading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[400px]">
                <Loader2 className="w-8 h-8 animate-spin text-primary mb-2" />
                <p className="text-muted-foreground">Ładowanie rezerwacji...</p>
            </div>
        );
    }

    return (
        <div className="space-y-6 p-4 max-w-4xl mx-auto">
            <div className="text-center space-y-2">
                <h1 className="text-3xl font-bold">Moje rezerwacje</h1>
                <p className="text-muted-foreground">Witaj {user?.first_Name}! Oto Twoje rezerwacje.</p>
            </div>

            <div className="flex justify-center gap-2 mb-8">
                <Badge variant="default" className="px-4 py-1 font-bold">
                    Nadchodzące ({reservations.length})
                </Badge>
                <Badge variant="outline" className="px-4 py-1 text-muted-foreground">
                    Zakończone (0)
                </Badge>
            </div>

            {reservations.length === 0 ? (
                <div className="text-center py-20 border-2 border-dashed rounded-3xl">
                    <p className="text-muted-foreground">Brak nadchodzących rezerwacji.</p>
                </div>
            ) : (
                <div className="grid gap-4">
                    {reservations.map((res) => (
                        <Card key={res.reservation_ID} className="overflow-hidden border-l-4 border-l-primary shadow-sm hover:shadow-md transition-shadow">
                            <CardContent className="p-6">
                                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                                    <div className="space-y-1">
                                        <h3 className="font-bold text-xl">{res.objectName}</h3>
                                        <div className="flex items-center text-muted-foreground gap-2">
                                            <MapPin className="w-4 h-4 text-primary" />
                                            <span className="text-sm font-medium">{res.roomName}</span>
                                            <span className="text-sm">— {res.address}</span>
                                        </div>
                                    </div>

                                    <div className="flex flex-wrap gap-4 bg-muted/30 p-3 rounded-xl">
                                        <div className="flex items-center gap-2">
                                            <Calendar className="w-4 h-4 text-primary" />
                                            <span className="font-bold">
                            {res.reservationDate
                                ? new Date(res.reservationDate).toLocaleDateString('pl-PL')
                                : "Brak daty"}
                        </span>
                                        </div>
                                        <div className="flex items-center gap-2 border-l pl-4">
                                            <Clock className="w-4 h-4 text-primary" />
                                            <span className="font-bold">
                            {}
                                                {res.reservationTime || "Brak godziny"}
                        </span>
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}