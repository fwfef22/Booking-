const API_BASE_URL = 'http://localhost:5000/api';

export interface ApiUser {
    user_ID: string;
    first_Name: string;
    last_Name: string;
    email: string;
    phone_Number?: string;
    role?: string;
}

export interface RegisterData {
    first_Name: string;
    last_Name: string;
    email: string;
    adres_Miasto: string;
    adres_Ulica_1: string;
    adres_Ulica_2?: string;
    adres_Budynek: string;
    adres_Pokoj?: string;
    adres_KodPocztowy: string;
    phone_Number: string;
    password: string;
    confirmPassword: string;
}

export interface LoginData {
    email: string;
    password: string;
}

export interface AuthResponse {
    success: boolean;
    message: string;
    user: ApiUser;
    token: string;
}

export interface ObjectData {
    name: string;
    rate: number;
    description: string;
    adres_Miasto: string;
    adres_Ulica_1: string;
    adres_Ulica_2?: string;
    adres_Budynek: string;
    adres_Pokoj?: string;
    adres_KodPocztowy: string;
    phone_Number: string;
    owner_ID: string;
    tagList: string[];
}

export interface ApiObject {
    object_ID: string;
    name: string;
    rate: number;
    description: string;
    adres_Miasto: string;
    adres_Ulica_1: string;
    adres_Ulica_2?: string;
    adres_Budynek: string;
    adres_Pokoj?: string;
    adres_KodPocztowy: string;
    phone_Number: string;
    owner_ID: string;
    tagList: string[];
    roomsList?: Room[];
    rentObjectRooms: ApiRoom[];
    facilities?: string[];
}

export interface Room {
    name: string;
    adres_Ulica_1: string;
    adres_Ulica_2?: string;
    adres_Budynek: string;
    adres_Pokoj?: string;
    adres_KodPocztowy: string;
}

export interface ApiRoom {
    rent_Object_Room_ID: string;
    room_Name: string;
    room_Capacity?: number;
}
// === RESERVATION ===
export interface CreateReservationRequest {
    rentObjectRoomId: string;
    userId: string;
    reservationDate_Time: string; // ISO
}

export interface CreateReservationResponse {
    success: boolean;
    message: string;
}

export const registerUser = async (data: RegisterData): Promise<AuthResponse> => {
    const dataToSend = {
        ...data,
        adres_Ulica_2: data.adres_Ulica_2 || "",
        adres_Pokoj: data.adres_Pokoj || ""
    };

    const url = `${API_BASE_URL}/User/register`;
    console.log('🔵 registerUser URL:', url);
    console.log('🔵 Sending data:', dataToSend);

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(dataToSend)
    });

    console.log('🔵 Response status:', res.status);

    if (!res.ok) {
        const errorText = await res.text();
        console.error('❌ Registration error:', {
            status: res.status,
            statusText: res.statusText,
            error: errorText
        });
        throw new Error(errorText || `HTTP error! status: ${res.status}`);
    }

    const result = await res.json();
    console.log('✅ Registration success:', result);
    return result;
};

export const loginUser = async (data: LoginData): Promise<AuthResponse> => {
    const url = `${API_BASE_URL}/User/login`;
    console.log('🔵 loginUser URL:', url);
    console.log('🔵 Sending data:', data);

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify(data)
    });

    console.log('🔵 Response status:', res.status);

    if (!res.ok) {
        const errorText = await res.text();
        console.error('❌ Login error:', {
            status: res.status,
            statusText: res.statusText,
            error: errorText
        });
        throw new Error(errorText || `HTTP error! status: ${res.status}`);
    }

    const result = await res.json();
    console.log('✅ Login success:', result);
    return result;
};

/*export const createObject = async (
    formData: any,
    facilities: string[],
    user: any,
    token: string
) => {
    const dataToSend = {
        name: formData.name,
        category: formData.category,
        description: formData.description,
        icon: formData.icon,
        default_Time: formData.duration,
        pay_for_Hour: formData.pricePerHour,
        frontEnd_Color: formData.color[0] || "b",
        adres_Miasto: formData.city,
        phone_Number: user?.phone_Number || "", // <- tutaj
        owner_ID: user?.user_ID,
        roomsList: facilities.map((facilityName) => ({
            name: facilityName,
            adres_Ulica_1: formData.adres_Ulica_1,
            adres_Ulica_2: formData.adres_Ulica_2?.trim() || "brak", // <- jeśli puste, wpisz "brak"
            adres_Budynek: formData.adres_Budynek,
            adres_Pokoj: formData.adres_Pokoj?.trim() || "brak",
            adres_KodPocztowy: formData.adres_KodPocztowy
        })),
        tagList: [formData.category || "other"]

    };

    const res = await fetch(`${API_BASE_URL}/Rent_Object/create-rent_object`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(dataToSend)
    });

    if (!res.ok) throw new Error(await res.text());
    return res.json();
};

 */
export const createObject = async (
    formData: any,
    facilities: string[],
    user: ApiUser,
    token: string
): Promise<ApiObject[]> => {
    const dataToSend = {
        name: formData.name,
        category: formData.category,
        description: formData.description,
        icon: formData.icon,
        default_Time: formData.duration,
        pay_for_Hour: formData.pricePerHour,
        frontEnd_Color: formData.color[0] || "b",
        adres_Miasto: formData.city,
        phone_Number: user.phone_Number || "",
        owner_ID: user.user_ID,
        roomsList: facilities.map((facilityName) => ({
            name: facilityName,
            adres_Ulica_1: formData.adres_Ulica_1,
            adres_Ulica_2: formData.adres_Ulica_2?.trim() || "brak",
            adres_Budynek: formData.adres_Budynek,
            adres_Pokoj: formData.adres_Pokoj?.trim() || "brak",
            adres_KodPocztowy: formData.adres_KodPocztowy
        })),
        tagList: [formData.category || "other"]
    };

    const res = await fetch(`${API_BASE_URL}/Rent_Object/create-rent_object`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(dataToSend)
    });

    if (!res.ok) throw new Error(await res.text());

    const objects = await getRentObjects(token);
    return objects.map(obj => ({
        ...obj,
        facilities: (obj.roomsList || []).map((room: any) => room.name)
    }));
};

export const getRentObjects = async (token: string, limit = 50, offset = 0): Promise<ApiObject[]> => {
    const res = await fetch(
        `${API_BASE_URL}/Rent_Object/RentObjectWithLimit?limit=${limit}&offset=${offset}`,
        { method: "GET", headers: { Authorization: `Bearer ${token}` } }
    );

    if (!res.ok) throw new Error(await res.text());

    const data: any[] = await res.json();

    return data.map(obj => ({
        ...obj,
        // Теперь используем roomList из ответа бэкенда
        rentObjectRooms: (obj.roomList || []).map((r: any) => ({
            rent_Object_Room_ID: r.rent_Object_Room_ID, //
            room_Name: r.name_Object_Room
        })),
        facilities: (obj.roomList || []).map((r: any) => r.name_Object_Room)
    }));
};

// Popraw też pozostałe funkcje:
/*
export const getUserById = async (id: string, token: string): Promise<ApiUser> => {
    const url = `${API_BASE_URL}/User/${id}`;
    console.log('🔵 getUserById URL:', url);

    const res = await fetch(url, {
        headers: {
            'Accept': 'application/json',
            Authorization: `Bearer ${token}`
        }
    });

    console.log('🔵 Response status:', res.status);

    if (!res.ok) {
        const errorText = await res.text();
        console.error('❌ Get user error:', errorText);
        throw new Error(errorText || `HTTP error! status: ${res.status}`);
    }

    return res.json();
};
*/
export const getObjectById = async (id: string): Promise<ApiObject> => {
    const url = `${API_BASE_URL}/Object/object-by-id/${id}`;
    console.log('🔵 getObjectById URL:', url);

    const res = await fetch(url, {
        headers: {
            'Accept': 'application/json'
        }
    });

    console.log('🔵 Response status:', res.status);

    if (!res.ok) {
        const errorText = await res.text();
        console.error('❌ Get object error:', errorText);
        throw new Error(errorText || `HTTP error! status: ${res.status}`);
    }

    return res.json();
};

export const getObjectsByTags = async (tags: string[]): Promise<ApiObject[]> => {
    const queryString = tags.map(tag => `tag=${encodeURIComponent(tag)}`).join('&');
    const url = `${API_BASE_URL}/Object/objects-by-tags?${queryString}`;
    console.log('🔵 getObjectsByTags URL:', url);

    const res = await fetch(url, {
        headers: {
            'Accept': 'application/json'
        }
    });

    console.log('🔵 Response status:', res.status);

    if (!res.ok) {
        const errorText = await res.text();
        console.error('❌ Get objects by tags error:', errorText);
        throw new Error(errorText || `HTTP error! status: ${res.status}`);
    }

    return res.json();
};
export const createReservation = async (
    data: CreateReservationRequest,
    token: string
): Promise<CreateReservationResponse> => {
    const res = await fetch(`${API_BASE_URL}/Reservation/create-reservation`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error(await res.text());
    return res.json();
};

export const getRoomDetailsById = async (roomId: string, token: string) => {
    const response = await fetch(`${API_BASE_URL}/Rent_Object/RentObjectRoomByID?RentObjRoomID=${roomId}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        }
    });

    if (!response.ok) throw new Error('Błąd pobierania szczegółów pokoju');
    return await response.json();
};

export const getUserReservations = async (userId: string, token: string) => {
    const res = await fetch(`${API_BASE_URL}/Reservation/ReservationByUserID?UserId=${userId}`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`,
            'Accept': 'application/json'
        }
    });

    if (!res.ok) throw new Error(await res.text());
    return res.json();
};
// === PAYMENT ===
export interface MakePaymentRequest {
    reservation_ID: string;
    amount: number;
}

export interface PaymentResponse {
    success: boolean;
    message: string;
}

export interface CreateReservationResponse {
    success: boolean;
    message: string;
    reservation_ID?: string;
}

export interface PaymentInfo {
    payment_ID: string;
    reservation_ID: string;
    amount: number;
    payment_Date: string;
    status: string;
}

export interface PaymentQueryParams {
    userId?: string;
    status?: string;
    dateFrom?: string;
    dateTo?: string;
}
export const makePayment = async (data: MakePaymentRequest, token: string): Promise<PaymentResponse> => {
    const res = await fetch(`${API_BASE_URL}/Payment/make-payment`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error(await res.text());
    return res.json();
};
// Dodaj te interfejsy
export interface AllowedSlot {
    time_span: string; // np. "10:00 - 11:00"
    isAllowed: boolean;
}

export interface AllowedSlotsRequest {
    date: string; // format ISO
    rentObjectRoomId: string;
}

// Dodaj tę funkcję
export const getAllowedSlots = async (
    data: AllowedSlotsRequest,
    token: string
): Promise<AllowedSlot[]> => {
    const res = await fetch(`${API_BASE_URL}/Reservation/AllowedSlotsByRoomIdAndDateDay`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error(await res.text());
    return res.json();
};
export const getPaymentById = async (paymentId: string, token: string): Promise<PaymentInfo> => {
    const res = await fetch(`${API_BASE_URL}/Payment/get-payment-by-id?id=${paymentId}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
};

export const getPaymentsByReservationId = async (reservationId: string, token: string): Promise<PaymentInfo[]> => {
    const res = await fetch(`${API_BASE_URL}/Payment/get-payments-by-reservation-id?reservationId=${reservationId}`, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` }
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
};

export const queryPayments = async (params: PaymentQueryParams, token: string): Promise<PaymentInfo[]> => {
    const res = await fetch(`${API_BASE_URL}/Payment/query-payments`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(params),
    });
    if (!res.ok) throw new Error(await res.text());
    return res.json();
};
